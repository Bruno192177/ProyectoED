/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mx.itson.terminal.entidades;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author bruns
 */
public class Terminal {
    
    private final String[] terminales = {
        "Navojoa", "Obregón", "Empalme", "Guaymas", "Hermosillo", "Santa Ana", "Magdalena", "Imuris", "Nogales"
    };
    
    private Autobus autobus;
    private double gananciaTotal;

    // Constructor
    public Terminal() {
        autobus = new Autobus();
        gananciaTotal = 0.0;
    }

    // Metodo principal para iniciar el viaje
    public void iniciarViaje() {
    Scanner scanner = new Scanner(System.in);

    for (int i = 0; i < terminales.length; i++) {
        System.out.println("\n=== Terminal actual: " + terminales[i] + " ===");
        autobus.mostrarAsientos();

        System.out.print("¿Hay pasajeros para subir? (s/n): ");
        String respuesta = scanner.nextLine();
        while (respuesta.equalsIgnoreCase("s")) {
            System.out.print("Nombre del pasajero: ");
            String nombre = scanner.nextLine();

            System.out.print("Destino del pasajero: ");
            String destino = scanner.nextLine();

            System.out.print("Precio del boleto: ");
            double precio = scanner.nextDouble();
            scanner.nextLine();

            System.out.print("Seleccione un asiento disponible: ");
            int asiento = scanner.nextInt();
            scanner.nextLine();

            Pasajero pasajero = new Pasajero(nombre, destino, precio, asiento);
            if (autobus.reservarAsiento(asiento, pasajero)) {
                gananciaTotal += precio;
            }

            System.out.print("¿Agregar otro pasajero? (s/n): ");
            respuesta = scanner.nextLine();
        }

        // Aqui llamamos al metodo para bajar pasajeros si no es la ultima terminal
        if (i < terminales.length - 1) {
            bajarPasajeros(terminales[i + 1]);
        }
    }

    // Al llegar a la ultima terminal mostramos el reporte final
    if (terminales[terminales.length - 1].equals("Nogales")) {
        mostrarReporteFinal();
    }

    scanner.close();
}



    // Metodo para bajar pasajeros en una terminal
    private void bajarPasajeros(String terminalActual) {
    ArrayList<Pasajero> pasajerosBajados = new ArrayList<>();
    for (Pasajero pasajero : autobus.getListaPasajeros()) {
        if (pasajero.getDestino().equalsIgnoreCase(terminalActual)) {
            pasajerosBajados.add(pasajero);
        }
    }

    for (Pasajero pasajero : pasajerosBajados) {
        autobus.liberarAsiento(pasajero.getAsiento());
    }

    System.out.println("Se bajan " + pasajerosBajados.size() + " pasajeros en " + terminalActual);
   
}

    // Metodo para mostrar el reporte final
    private void mostrarReporteFinal() {
    System.out.println("\n=== Reporte Final del Viaje ===");
    System.out.println("Listado de pasajeros:");
    
    if (autobus.getListaPasajeros().isEmpty()) {
        System.out.println("No hay pasajeros registrados.");
    } else {
        for (Pasajero pasajero : autobus.getListaPasajeros()) {
            System.out.println("Nombre: " + pasajero.getNombre() + ", Origen: Navojoa, " + ", Destino: " + pasajero.getDestino() + ", Precio: $" + pasajero.getPrecio() + ", Asiento: " + pasajero.getAsiento());
        }
    }
    
    System.out.println("\nGanancia total del viaje: $" + gananciaTotal);
}

}
