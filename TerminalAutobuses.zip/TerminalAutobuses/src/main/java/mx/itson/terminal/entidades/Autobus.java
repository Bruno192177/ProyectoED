/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mx.itson.terminal.entidades;

import java.util.ArrayList;

/**
 *
 * @author bruns
 */
public class Autobus {
    
    private boolean[] asientos;
    private ArrayList<Pasajero> listaPasajeros;

    public Autobus() {
        this.asientos = new boolean[20]; // 20 asientos disponibles
        this.listaPasajeros = new ArrayList<>();
    }

    public ArrayList<Pasajero> getListaPasajeros() {
        return listaPasajeros;
    }

    // Metodo para reservar un asiento
    public boolean reservarAsiento(int asiento, Pasajero pasajero) {
        if (asiento >= 0 && asiento < 20 && !asientos[asiento]) {
            asientos[asiento] = true; // Marcar asiento como ocupado
            listaPasajeros.add(pasajero); // Agregar pasajero a la lista
            return true;
        }
        return false;
    }

    // Metodo para liberar un asiento cuando el pasajero se baja
    public void liberarAsiento(int asiento) {
        if (asiento >= 0 && asiento < 20) {
            asientos[asiento] = false; // Marcar asiento como libre
        }
    }

    // Mostrar los asientos disponibles y ocupados
    public void mostrarAsientos() {
        System.out.println("\nAsientos disponibles (numerados):");

    int asientoNumber = 0; 

    for (int i = 0; i < 5; i++) {
        System.out.print(String.format("[%2d(%s)] ", asientoNumber, asientos[(i * 4)] ? "X" : " "));
        asientoNumber++;

        System.out.print(String.format("[%2d(%s)] ", asientoNumber, asientos[(i * 4) + 1] ? "X" : " "));
        asientoNumber++;

        System.out.print("   "); 

        System.out.print(String.format("[%2d(%s)] ", asientoNumber, asientos[(i * 4) + 2] ? "X" : " "));
        asientoNumber++;

        System.out.print(String.format("[%2d(%s)] ", asientoNumber, asientos[(i * 4) + 3] ? "X" : " "));
        asientoNumber++;

        System.out.println(); 
    }
    
    }

}
